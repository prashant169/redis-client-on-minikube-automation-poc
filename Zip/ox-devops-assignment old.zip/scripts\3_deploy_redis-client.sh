#!/bin/bash
set -e

helm install redis-client ./helm-chart-redis-client

