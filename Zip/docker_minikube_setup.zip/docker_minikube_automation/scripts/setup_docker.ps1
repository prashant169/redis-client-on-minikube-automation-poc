Write-Host "📦 Checking for Docker Desktop..."

$installerUrl = "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe"
$installerPath = "$env:TEMP\DockerDesktopInstaller.exe"
$dockerExe = "C:\Program Files\Docker\Docker\Docker Desktop.exe"

$dockerInstalled = Get-Command "docker" -ErrorAction SilentlyContinue

if ($dockerInstalled) {
    Write-Host "✅ Docker CLI already installed."
} elseif (Test-Path $dockerExe) {
    Write-Host "✅ Docker Desktop is already installed."
} else {
    Write-Host "⬇️ Downloading Docker Desktop installer..."
    Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath

    if (-Not (Test-Path $installerPath)) {
        Write-Error "❌ Failed to download Docker installer."
        exit 1
    }

    Write-Host "🚀 Installing Docker Desktop (silent mode)..."
    Start-Process -FilePath $installerPath -ArgumentList "install", "--quiet" -Wait

    if ($LASTEXITCODE -ne 0) {
        Write-Error "❌ Docker installation failed."
        exit 1
    }

    Write-Host "✅ Docker Desktop installation complete."
}

if (Test-Path $dockerExe) {
    Write-Host "🚀 Launching Docker Desktop..."
    Start-Process -FilePath "$dockerExe"
    Start-Sleep -Seconds 10
} else {
    Write-Error "❌ Docker executable not found even after install."
    exit 1
}

Write-Host "⏳ Waiting for Docker daemon..."

$maxWait = 60
$waited = 0

while ($waited -lt $maxWait) {
    try {
        docker info > $null 2>&1
        if ($?) {
            Write-Host "✅ Docker is running!"
            exit 0
        }
    } catch {}
    Start-Sleep -Seconds 3
    $waited += 3
}

Write-Error "Docker daemon did not start within timeout."
exit 1
